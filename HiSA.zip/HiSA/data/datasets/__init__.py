from .charades_sta import CHARADES_STA
from .anet_cap import ANET_CAP
# from .anet_capold import ANET_CAP

from .tacos import TACOS
__all__ = ["CHARADES_STA", "ANET_CAP","TACOS"]
